import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProfileSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Profiles API routes
  
  // Get all profiles
  app.get("/api/profiles", async (req, res) => {
    try {
      const profiles = await storage.getAllProfiles();
      return res.json(profiles);
    } catch (error) {
      console.error("Error fetching profiles:", error);
      return res.status(500).json({ error: "Failed to fetch profiles" });
    }
  });

  // Get profile by ID
  app.get("/api/profiles/:id", async (req, res) => {
    try {
      const profile = await storage.getProfile(req.params.id);
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      return res.json(profile);
    } catch (error) {
      console.error(`Error fetching profile ${req.params.id}:`, error);
      return res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  // Create a new profile
  app.post("/api/profiles", async (req, res) => {
    try {
      const profileData = insertProfileSchema.parse(req.body);
      const newProfile = await storage.createProfile(profileData);
      return res.status(201).json(newProfile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating profile:", error);
      return res.status(500).json({ error: "Failed to create profile" });
    }
  });

  // Update a profile
  app.put("/api/profiles/:id", async (req, res) => {
    try {
      const { id, ...profileData } = insertProfileSchema.parse({
        ...req.body,
        id: req.params.id
      });
      
      const updatedProfile = await storage.updateProfile(id, profileData);
      
      if (!updatedProfile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      
      return res.json(updatedProfile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error(`Error updating profile ${req.params.id}:`, error);
      return res.status(500).json({ error: "Failed to update profile" });
    }
  });

  // Delete a profile
  app.delete("/api/profiles/:id", async (req, res) => {
    try {
      const success = await storage.deleteProfile(req.params.id);
      
      if (!success) {
        return res.status(404).json({ error: "Profile not found" });
      }
      
      return res.json({ success: true });
    } catch (error) {
      console.error(`Error deleting profile ${req.params.id}:`, error);
      return res.status(500).json({ error: "Failed to delete profile" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
