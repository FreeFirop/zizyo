export interface Profile {
  id: string;
  name: string;
  description: string;
  image: string | null;
}

export type CreateProfileData = Omit<Profile, 'id'>;
