import { Button } from "@/components/ui/button";
import { Users } from "lucide-react";

interface EmptyStateProps {
  onCreateProfile: () => void;
}

export function EmptyState({ onCreateProfile }: EmptyStateProps) {
  return (
    <div className="col-span-full py-16 flex flex-col items-center justify-center text-center">
      <div className="w-24 h-24 rounded-full bg-secondary/30 flex items-center justify-center mb-6">
        <Users className="h-12 w-12 text-primary animate-pulse" />
      </div>
      
      <h3 className="text-2xl font-semibold text-foreground mb-3">No profiles yet</h3>
      <p className="text-muted-foreground max-w-md mx-auto mb-8">
        Start building your collection by creating your first profile
      </p>
      
      <Button 
        className="bg-primary hover:bg-primary/90 text-white py-2 px-6 rounded-xl font-medium transition-all duration-200 shadow-md hover:shadow-xl hover:translate-y-[-2px]"
        onClick={onCreateProfile}
        size="lg"
      >
        Create New Profile
      </Button>
    </div>
  );
}
