import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Profile } from '@/types/profile';
import { Pencil, Trash2, User } from 'lucide-react';
import { 
  AlertDialog, 
  AlertDialogAction, 
  AlertDialogCancel, 
  AlertDialogContent, 
  AlertDialogDescription, 
  AlertDialogFooter, 
  AlertDialogHeader, 
  AlertDialogTitle, 
  AlertDialogTrigger 
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';

interface ProfileCardProps {
  profile: Profile;
  onEdit: (profile: Profile) => void;
  onDelete: (id: string) => void;
}

export function ProfileCard({ profile, onEdit, onDelete }: ProfileCardProps) {
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = () => {
    setIsDeleting(true);
    onDelete(profile.id);
    setIsDeleting(false);
  };

  return (
    <Card className="rounded-xl overflow-hidden border hover:translate-y-[-4px] transition-all duration-300 shadow-md hover:shadow-xl">
      <div className="w-full h-48 bg-gradient-to-b from-secondary to-background relative group">
        {profile.image ? (
          <img 
            src={profile.image} 
            alt={`${profile.name}'s profile`} 
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-48 flex items-center justify-center">
            <User className="h-16 w-16 text-muted-foreground opacity-50" />
          </div>
        )}
        <div className="absolute bottom-2 right-2">
          <Badge variant="secondary" className="text-xs font-medium">
            ID: {profile.id.slice(-4)}
          </Badge>
        </div>
      </div>
      
      <CardContent className="p-5">
        <h3 className="text-xl font-semibold mb-1 text-foreground">{profile.name}</h3>
        <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{profile.description}</p>
        
        <div className="flex justify-end space-x-2">
          <Button 
            variant="outline" 
            size="icon" 
            className="rounded-full hover:bg-primary/10 hover:text-primary transition-all duration-200"
            onClick={() => onEdit(profile)}
          >
            <Pencil className="h-4 w-4" />
          </Button>
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button 
                variant="outline" 
                size="icon" 
                className="rounded-full hover:bg-destructive/10 hover:text-destructive transition-all duration-200"
                disabled={isDeleting}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Profile</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to delete this profile? This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  onClick={handleDelete}
                >
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardContent>
    </Card>
  );
}
