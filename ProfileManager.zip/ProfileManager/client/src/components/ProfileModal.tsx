import { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Profile, CreateProfileData } from '@/types/profile';
import { Camera, Trash, UserPlus, UserCog } from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (profileData: CreateProfileData) => void;
  editingProfile: Profile | null;
}

export function ProfileModal({ isOpen, onClose, onSave, editingProfile }: ProfileModalProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);

  // Reset form when modal opens/closes or editing profile changes
  useEffect(() => {
    if (isOpen) {
      if (editingProfile) {
        setName(editingProfile.name);
        setDescription(editingProfile.description);
        setImagePreviewUrl(editingProfile.image);
      } else {
        // Reset form for new profile
        setName('');
        setDescription('');
        setImagePreviewUrl(null);
      }
    }
  }, [isOpen, editingProfile]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const reader = new FileReader();
    reader.onload = () => {
      setImagePreviewUrl(reader.result as string);
    };
    reader.readAsDataURL(files[0]);
  };

  const removeImage = () => {
    setImagePreviewUrl(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const profileData: CreateProfileData = {
      name,
      description,
      image: imagePreviewUrl
    };
    
    onSave(profileData);
    onClose();
  };

  const isEditing = Boolean(editingProfile);
  const modalTitle = isEditing ? 'Edit Profile' : 'Create Profile';
  const Icon = isEditing ? UserCog : UserPlus;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Icon className="h-5 w-5 text-primary" />
            <DialogTitle className="text-xl font-semibold">{modalTitle}</DialogTitle>
          </div>
          <DialogDescription>
            {isEditing 
              ? "Update the profile information below" 
              : "Fill in the details to create a new profile"}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="py-4">
          <div className="mb-6">
            <Label htmlFor="profileName" className="text-sm font-medium mb-1">Name</Label>
            <Input 
              id="profileName"
              placeholder="Enter profile name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          
          <div className="mb-6">
            <Label htmlFor="profileDescription" className="text-sm font-medium mb-1">Description</Label>
            <Textarea 
              id="profileDescription"
              placeholder="Describe this profile..."
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>
          
          <div className="mb-6">
            <Label className="block text-sm font-medium mb-2">Profile Image</Label>
            <div className="flex items-center gap-4">
              <div className="w-32 h-32 rounded-lg flex items-center justify-center overflow-hidden bg-secondary/30 border border-border">
                {imagePreviewUrl ? (
                  <img
                    src={imagePreviewUrl}
                    alt="Profile preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Camera className="h-12 w-12 text-muted-foreground opacity-50" />
                )}
              </div>
              <div className="flex flex-col gap-2">
                <Label 
                  htmlFor="profileImage"
                  className="bg-primary hover:bg-primary/90 text-white py-2 px-4 rounded-md font-medium text-sm cursor-pointer transition-all duration-200 inline-block text-center shadow-sm"
                >
                  Upload Image
                </Label>
                <Input 
                  type="file"
                  id="profileImage"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageUpload}
                />
                {imagePreviewUrl && (
                  <Button
                    type="button"
                    variant="outline"
                    className="border-destructive/30 hover:bg-destructive/10 hover:text-destructive transition-colors duration-200"
                    onClick={removeImage}
                  >
                    <Trash className="h-4 w-4 mr-2" />
                    Remove Image
                  </Button>
                )}
              </div>
            </div>
          </div>
          
          <DialogFooter className="flex justify-end gap-3 pt-2">
            <Button 
              type="button" 
              variant="outline"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-primary hover:bg-primary/90 text-white"
            >
              {isEditing ? 'Update Profile' : 'Save Profile'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
