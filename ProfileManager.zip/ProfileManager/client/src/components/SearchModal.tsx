import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Profile } from '@/types/profile';
import { useToast } from '@/hooks/use-toast';
import { 
  AlertDialog, 
  AlertDialogAction, 
  AlertDialogContent, 
  AlertDialogDescription, 
  AlertDialogFooter, 
  AlertDialogHeader, 
  AlertDialogTitle 
} from '@/components/ui/alert-dialog';
import { Search, User, Check, XCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSearch: (id: string) => Promise<Profile | null>;
}

export function SearchModal({ isOpen, onClose, onSearch }: SearchModalProps) {
  const [searchId, setSearchId] = useState('');
  const [searchResult, setSearchResult] = useState<Profile | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchId.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter a profile ID',
        variant: 'destructive',
      });
      return;
    }
    
    setIsSearching(true);
    
    try {
      const result = await onSearch(searchId.trim());
      setSearchResult(result);
      setShowResult(true);
      
      if (!result) {
        toast({
          title: 'Not Found',
          description: 'No profile found with the given ID',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error searching for profile:', error);
      toast({
        title: 'Error',
        description: 'An error occurred while searching for the profile',
        variant: 'destructive',
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleClose = () => {
    setSearchId('');
    setSearchResult(null);
    setShowResult(false);
    onClose();
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="flex items-center gap-2">
              <Search className="h-5 w-5 text-primary" />
              <DialogTitle className="text-xl font-semibold">Search Profiles</DialogTitle>
            </div>
            <DialogDescription>
              Enter a profile ID to find a specific profile
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="py-4">
            <div className="mb-6">
              <Label htmlFor="searchProfileId" className="text-sm font-medium mb-1">Profile ID</Label>
              <Input 
                id="searchProfileId"
                placeholder="Enter the ID of the profile you want to find"
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                required
              />
            </div>
            
            <DialogFooter className="flex justify-end gap-3">
              <Button 
                type="button" 
                variant="outline"
                onClick={handleClose}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-primary hover:bg-primary/90 text-white"
              >
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Result Dialog */}
      <AlertDialog open={showResult} onOpenChange={setShowResult}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <div className="flex items-center gap-2">
              {searchResult ? (
                <Check className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-destructive" />
              )}
              <AlertDialogTitle>
                {searchResult ? 'Profile Found' : 'Profile Not Found'}
              </AlertDialogTitle>
            </div>
            <AlertDialogDescription>
              {searchResult ? (
                <Card className="mt-4 border border-border/50">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="h-16 w-16 rounded-full overflow-hidden bg-secondary/30 flex items-center justify-center">
                        {searchResult.image ? (
                          <img 
                            src={searchResult.image} 
                            alt={`${searchResult.name}'s profile`}
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <User className="h-8 w-8 text-muted-foreground opacity-50" />
                        )}
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-foreground">{searchResult.name}</h3>
                        <Badge variant="outline" className="mt-1 text-xs">
                          ID: {searchResult.id}
                        </Badge>
                      </div>
                    </div>
                    <div className="border-t border-border/50 pt-3 mt-2">
                      <p className="text-muted-foreground">{searchResult.description}</p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <p className="mt-2">No profile found with the provided ID. Please check the ID and try again.</p>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction 
              className="bg-primary hover:bg-primary/90 text-white"
              onClick={() => setShowResult(false)}
            >
              Close
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
