import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ProfileCard } from '@/components/ProfileCard';
import { EmptyState } from '@/components/EmptyState';
import { ProfileModal } from '@/components/ProfileModal';
import { SearchModal } from '@/components/SearchModal';
import { ThemeToggler } from '@/components/ThemeToggler';
import { useProfiles } from '@/hooks/useProfiles';
import { Profile, CreateProfileData } from '@/types/profile';
import { PlusCircle, Search, Layers } from 'lucide-react';

export default function Home() {
  const { profiles, isLoading, createProfile, updateProfile, deleteProfile, searchProfile } = useProfiles();
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [editingProfile, setEditingProfile] = useState<Profile | null>(null);

  const handleCreateProfile = () => {
    setEditingProfile(null);
    setIsProfileModalOpen(true);
  };

  const handleEditProfile = (profile: Profile) => {
    setEditingProfile(profile);
    setIsProfileModalOpen(true);
  };

  const handleSaveProfile = (profileData: CreateProfileData) => {
    if (editingProfile) {
      updateProfile(editingProfile.id, profileData);
    } else {
      createProfile(profileData);
    }
  };

  const handleCloseProfileModal = () => {
    setIsProfileModalOpen(false);
    setEditingProfile(null);
  };

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      <div className="container mx-auto px-4 py-10">
        {/* Header Section */}
        <header className="mb-10 relative">
          <div className="absolute right-0 top-0">
            <ThemeToggler />
          </div>
          
          <div className="flex flex-col items-center text-center mb-6 pt-4">
            <div className="flex items-center mb-3">
              <Layers className="h-8 w-8 text-primary mr-2" />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-purple-500 bg-clip-text text-transparent">
                Profile Manager
              </h1>
            </div>
            <p className="text-muted-foreground max-w-md">
              Create, view, edit and manage user profiles with a beautiful interface
            </p>
          </div>
          
          <div className="flex justify-center gap-4 mb-6">
            <Button 
              className="bg-primary hover:bg-primary/90 text-white py-2 px-5 rounded-lg font-medium flex items-center transition-all duration-200 shadow-md hover:shadow-xl hover:translate-y-[-2px]"
              onClick={handleCreateProfile}
            >
              <PlusCircle className="h-5 w-5 mr-2" />
              Create Profile
            </Button>
            <Button 
              variant="outline"
              className="py-2 px-5 rounded-lg font-medium flex items-center transition-all duration-200 shadow-sm hover:shadow-md hover:translate-y-[-2px]"
              onClick={() => setIsSearchModalOpen(true)}
            >
              <Search className="h-5 w-5 mr-2" />
              Search
            </Button>
          </div>
          
          <div className="w-full max-w-3xl mx-auto">
            <div className="h-1 w-full bg-gradient-to-r from-primary/50 via-purple-500/50 to-primary/50 rounded-full" />
          </div>
        </header>

        {/* Profile Card Container */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
          {isLoading ? (
            // Loading skeleton
            Array.from({ length: 4 }).map((_, index) => (
              <div key={index} className="rounded-lg border bg-card text-card-foreground shadow-sm animate-pulse">
                <div className="p-6 space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="h-16 w-16 rounded-full bg-secondary/30"></div>
                    <div className="space-y-2">
                      <div className="h-4 w-24 bg-secondary/30 rounded"></div>
                      <div className="h-3 w-16 bg-secondary/30 rounded"></div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-3 w-full bg-secondary/30 rounded"></div>
                    <div className="h-3 w-3/4 bg-secondary/30 rounded"></div>
                  </div>
                </div>
              </div>
            ))
          ) : profiles.length === 0 ? (
            <EmptyState onCreateProfile={handleCreateProfile} />
          ) : (
            profiles.map((profile: Profile) => (
              <ProfileCard
                key={profile.id}
                profile={profile}
                onEdit={handleEditProfile}
                onDelete={deleteProfile}
              />
            ))
          )}
        </div>
      </div>

      {/* Modals */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={handleCloseProfileModal}
        onSave={handleSaveProfile}
        editingProfile={editingProfile}
      />

      <SearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        onSearch={searchProfile}
      />
    </div>
  );
}
