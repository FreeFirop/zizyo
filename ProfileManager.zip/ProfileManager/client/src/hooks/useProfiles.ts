import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Profile, CreateProfileData } from '@/types/profile';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

export function useProfiles() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch all profiles
  const { 
    data: profiles = [], 
    isLoading,
    error,
    refetch 
  } = useQuery<Profile[]>({
    queryKey: ['/api/profiles'],
    refetchOnWindowFocus: false,
  });

  // Show toast if there's an error loading profiles
  if (error) {
    console.error('Failed to load profiles:', error);
    toast({
      title: 'Error',
      description: 'Failed to load profiles from the server',
      variant: 'destructive',
    });
  }

  // Create a new profile
  const createProfileMutation = useMutation({
    mutationFn: async (profileData: CreateProfileData) => {
      const newProfile: Profile & { id: string } = {
        ...profileData,
        id: Date.now().toString(), // Generate ID client-side
      };
      
      return apiRequest<Profile>('/api/profiles', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newProfile),
      });
    },
    onSuccess: () => {
      // Invalidate profiles cache to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/profiles'] });
      
      toast({
        title: 'Success',
        description: 'Profile created successfully',
      });
    },
    onError: (error) => {
      console.error('Failed to create profile:', error);
      toast({
        title: 'Error',
        description: 'Failed to create profile',
        variant: 'destructive',
      });
    },
  });

  // Update an existing profile
  const updateProfileMutation = useMutation({
    mutationFn: async ({ id, profileData }: { id: string; profileData: CreateProfileData }) => {
      return apiRequest<Profile>(`/api/profiles/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(profileData),
      });
    },
    onSuccess: () => {
      // Invalidate profiles cache to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/profiles'] });
      
      toast({
        title: 'Success',
        description: 'Profile updated successfully',
      });
    },
    onError: (error) => {
      console.error('Failed to update profile:', error);
      toast({
        title: 'Error',
        description: 'Failed to update profile',
        variant: 'destructive',
      });
    },
  });

  // Delete a profile
  const deleteProfileMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest<{ success: boolean }>(`/api/profiles/${id}`, {
        method: 'DELETE',
      });
      
      return id;
    },
    onSuccess: () => {
      // Invalidate profiles cache to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/profiles'] });
      
      toast({
        title: 'Success',
        description: 'Profile deleted successfully',
      });
    },
    onError: (error) => {
      console.error('Failed to delete profile:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete profile',
        variant: 'destructive',
      });
    },
  });

  // Create a new profile wrapper function
  const createProfile = (profileData: CreateProfileData) => {
    return createProfileMutation.mutateAsync(profileData);
  };

  // Update a profile wrapper function
  const updateProfile = (id: string, profileData: CreateProfileData) => {
    return updateProfileMutation.mutateAsync({ id, profileData });
  };

  // Delete a profile wrapper function
  const deleteProfile = (id: string) => {
    return deleteProfileMutation.mutateAsync(id);
  };

  // Search for a profile by ID
  const searchProfile = async (id: string) => {
    try {
      return await apiRequest<Profile>(`/api/profiles/${id}`, {
        method: 'GET',
      });
    } catch (error) {
      console.error(`Failed to find profile with ID ${id}:`, error);
      return null;
    }
  };

  return {
    profiles,
    isLoading: isLoading || createProfileMutation.isPending || updateProfileMutation.isPending || deleteProfileMutation.isPending,
    createProfile,
    updateProfile,
    deleteProfile,
    searchProfile,
    refetch,
  };
}
